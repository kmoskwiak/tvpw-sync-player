(function (){
    
    var syncPlayer = document.getElementById('sync-player');
    var playButton = document.getElementById('play-button');
    var player = document.getElementById('video-player');
    var fullscreenPlayer = document.getElementById('fullscreen-button');

    playButton.addEventListener('click', function(){
        if(player.paused){
            player.play();
        } else {
            player.pause();
        }
    });

    fullscreenPlayer.addEventListener('click', function(){
        syncPlayer.requestFullscreen = syncPlayer.requestFullscreen || syncPlayer.webkitRequestFullscreen || syncPlayer.mozRequestFullScreen;
        document.fullscreenElement = document.fullscreenElement || document.webkitFullscreenElement || document.mozFullScreenElement;
        document.exitFullscreen = document.exitFullscreen || document.webkitCancelFullScreen || syncPlayer.mozRequestExitFullScreen;

        if(document.fullscreenElement) {
            document.exitFullscreen();
            document.fullscreenElement = null;
        } else {
            syncPlayer.requestFullscreen(); 
        }
    })


})();

